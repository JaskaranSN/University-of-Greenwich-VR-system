
</div>
</div>


<footer>
    <div class="navbar navbar-inverse footer">
        <div class="container-fluid">
            <div class="copyright">
                <a href="http://localhost/multi-user-admin/index.php" target="_blank">&copy; Jaskaran Singh Natt   - <?php echo date("Y"); ?></a> All rights reserved
            </div>

        </div>
    </div>
</footer>



<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="bootstrap/js/jquery-1.9.0.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>